package com.hxl.myapplication;

public class MyAdapter_test {
}
