package com.hxl.myapplication;

/**
 * 商品信息
 * 作者：fly on 2016/8/24 0024 23:47
 * 邮箱：cugb_feiyang@163.com
 */
public class OrderGoods {

    private String goodName;
    private String goodSn;

    public String getGoodName() {
        return goodName;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public String getGoodSn() {
        return goodSn;
    }

    public void setGoodSn(String goodSn) {
        this.goodSn = goodSn;
    }
}


