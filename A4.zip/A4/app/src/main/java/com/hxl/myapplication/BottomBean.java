package com.hxl.myapplication;

/**
 * @author justin on 2016/08/28 02:02
 *         justin@magicare.me
 * @version V1.0
 */
public class BottomBean {

}
